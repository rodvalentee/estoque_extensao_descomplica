import React, { useState } from 'react';
import './App.css'
import Dashboard from './components/Dashboard';
import MovementForm from './components/MovementForm';
import MovementHistory from './components/MovementHistory';

function App() {
    const [showForm, setShowForm] = useState(false);
    const [showHistory, setShowHistory] = useState(false);
    const [reload, setReload] = useState(false);
    return (
        <>
            {!showHistory && (
                <Dashboard
                    onMovimentar={() => setShowForm(true)}
                    onShowHistory={() => setShowHistory(true)}
                    reload={reload}
                />
            )}

            {showForm && (
                <MovementForm
                    onClose={() => setShowForm(false)}
                    onSaved={() => setReload(r => !r)}
                />
            )}

            {showHistory && (
                <MovementHistory onCloseHistory={() => setShowHistory(false)} />
            )}
        </>
    );
}

export default App
