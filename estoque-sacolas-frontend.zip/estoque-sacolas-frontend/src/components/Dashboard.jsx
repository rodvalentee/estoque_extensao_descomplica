import React, { useState, useEffect } from 'react';
import { fetchStock } from '../api/stock';

export default function Dashboard({ reload, onMovimentar, onShowHistory }) {
    const [stock, setStock] = useState([]);

    useEffect(() => {
        fetchStock().then(data => setStock(data));
    }, [reload]);

    // 1) Define a ordem fixa dos tamanhos
    const sizeOrder = ['L30', 'L50', 'L100', 'L200'];

    // 2) Gera um array exatamente nessa ordem, descartando itens ausentes
    const orderedStock = sizeOrder
        .map(sizeKey => stock.find(item => item.size === sizeKey))
        .filter(Boolean);

    return (
        <div style={{ maxWidth: '960px', margin: '0 auto', padding: '1rem' }}>
            {/* Header */}
            <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '1.5rem'
            }}>
                <h1 style={{ color: '#333', margin: 0 }}>Estoque de Sacolas</h1>
                <button
                    onClick={onMovimentar}
                    style={{
                        marginLeft: '1rem',
                        backgroundColor: '#28A745',
                        border: 'none',
                        borderRadius: '4px',
                        color: 'white',
                        padding: '0.5rem 1rem',
                        cursor: 'pointer'
                    }}
                >
                    Movimentar
                </button>
            </div>

            {/* Grid de Cards */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(4, minmax(160px, 1fr))',
                gap: '1rem'
            }}>
                {orderedStock.map(item => (
                    <div key={item.size} style={{
                        background: 'white',
                        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                        borderRadius: '8px',
                        padding: '1rem',
                        textAlign: 'center'
                    }}>
                        <div style={{ fontSize: '1.5rem', fontWeight: 600, color: '#333' }}>
                            {`${item.size.substring(1)} L`}
                        </div>
                        <div style={{ marginTop: '0.5rem', color: '#555' }}>
                            Quant: {item.quantity}
                        </div>
                    </div>
                ))}
            </div>

            {/* Link para Histórico */}
            <div style={{ marginTop: '2rem', textAlign: 'center' }}>
                <a href="#"
                   onClick={e => { e.preventDefault(); onShowHistory(); }}
                   style={{
                    color: '#333',
                    textDecoration: 'none',
                    fontWeight: 500,
                    display: 'inline-flex',
                    alignItems: 'center'
                }}>
                    Histórico de Movimentações&nbsp;&raquo;
                </a>
            </div>
        </div>
    );
}
