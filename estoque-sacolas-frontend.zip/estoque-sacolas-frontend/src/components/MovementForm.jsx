import React, { useState } from 'react';
import { postEntry, postExit, postAdjustment } from '../api/movements';

export default function MovementForm({ onClose, onSaved }) {
    const [type, setType] = useState('ENTRY');
    const [size, setSize] = useState('L30');
    const [quantity, setQuantity] = useState('');
    const [extra, setExtra] = useState('');

    const handleSubmit = async e => {
        e.preventDefault();
        const payload = { size, quantity: Number(quantity) };
        if (type === 'EXIT')       payload.client = extra;
        else if (type === 'ADJUSTMENT') payload.reason = extra;

        try {
            if (type === 'ENTRY')      await postEntry(payload);
            if (type === 'EXIT')       await postExit(payload);
            if (type === 'ADJUSTMENT') await postAdjustment(payload);
            onSaved();
            onClose();
        } catch (err) {
            console.error(err);
            alert('Erro ao registrar movimentação.');
        }
    };

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0,
            width: '100%', height: '100%',
            background: 'rgba(0,0,0,0.3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
        }}>
            <form onSubmit={handleSubmit} style={{
                background: 'white', padding: '1.5rem', borderRadius: '8px',
                minWidth: '320px', boxShadow: '0 2px 6px rgba(0,0,0,0.2)'
            }}>
                <h2 style={{ marginTop: 0, color: '#333' }}>Nova Movimentação</h2>

                <label>Tipo</label><br/>
                <select
                    value={type}
                    onChange={e => { setType(e.target.value); setExtra(''); }}
                    style={{ width: '100%', marginBottom: '0.5rem' }}
                >
                    <option value="ENTRY">Entrada</option>
                    <option value="EXIT">Saída</option>
                    <option value="ADJUSTMENT">Ajuste</option>
                </select>

                <label>Tamanho</label><br/>
                <select
                    value={size}
                    onChange={e => setSize(e.target.value)}
                    style={{ width: '100%', marginBottom: '0.5rem' }}
                >
                    <option value="L30">30 L</option>
                    <option value="L50">50 L</option>
                    <option value="L100">100 L</option>
                    <option value="L200">200 L</option>
                </select>

                <label>Quantidade</label><br/>
                <input
                    type="number" min="1" required
                    value={quantity}
                    onChange={e => setQuantity(e.target.value)}
                    style={{ width: '100%', marginBottom: '0.5rem' }}
                />

                {(type === 'EXIT' || type === 'ADJUSTMENT') && (
                    <>
                        <label>{type === 'EXIT' ? 'Cliente' : 'Motivo'}</label><br/>
                        <input
                            type="text" required
                            value={extra}
                            onChange={e => setExtra(e.target.value)}
                            style={{ width: '100%', marginBottom: '0.5rem' }}
                        />
                    </>
                )}

                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '1rem' }}>
                    <button
                        type="button"
                        onClick={onClose}
                        style={{
                            background: '#ccc', border: 'none',
                            padding: '0.5rem 1rem', borderRadius: '4px',
                            cursor: 'pointer'
                        }}
                    >
                        Cancelar
                    </button>
                    <button
                        type="submit"
                        style={{
                            background: '#28A745', color: 'white',
                            border: 'none', padding: '0.5rem 1rem',
                            borderRadius: '4px', cursor: 'pointer'
                        }}
                    >
                        Confirmar
                    </button>
                </div>
            </form>
        </div>
    );
}
