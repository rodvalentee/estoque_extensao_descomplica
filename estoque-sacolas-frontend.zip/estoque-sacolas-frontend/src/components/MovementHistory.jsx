// src/components/MovementHistory.jsx
import React, { useState, useEffect } from 'react';
import { fetchMovements } from '../api/movements';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export default function MovementHistory({ onCloseHistory }) {
    const [movements, setMovements] = useState([]);
    const [sizeFilter, setSizeFilter] = useState('');
    const [startDate, setStartDate]   = useState('');
    const [endDate, setEndDate]       = useState('');
    const [searchText, setSearchText] = useState('');

    useEffect(() => {
        fetchMovements().then(data => setMovements(data));
    }, []);

    const filtered = movements.filter(m => {
        if (sizeFilter && m.size !== sizeFilter) return false;
        const dt = new Date(m.date);
        if (startDate && dt < new Date(startDate)) return false;
        if (endDate   && dt > new Date(endDate))   return false;
        if (searchText) {
            const txt    = searchText.toLowerCase();
            const client = (m.client || '').toLowerCase();
            const reason = (m.reason || '').toLowerCase();
            if (!client.includes(txt) && !reason.includes(txt)) return false;
        }
        return true;
    });

    const handleExportPDF = () => {
        const doc = new jsPDF();
        doc.setFontSize(18);
        doc.text('Relatório de Movimentações', 14, 22);

        const head = [['Data', 'Tamanho', 'Tipo', 'Qtde', 'Cliente/Motivo']];
        const body = filtered.map(m => [
            new Date(m.date).toLocaleString(),
            `${m.size.substring(1)} L`,
            m.type === 'ENTRY'      ? 'Entrada'
                : m.type === 'EXIT'   ? 'Saída'
                    :                       'Ajuste',
            m.quantity.toString(),
            m.type === 'EXIT'
                ? m.client
                : m.type === 'ADJUSTMENT'
                    ? m.reason
                    : '—'
        ]);

        autoTable(doc, {
            startY: 30,
            head,
            body,
            styles: { fontSize: 10 },
            headStyles: { fillColor: [40, 167, 69] }
        });

        doc.save('movimentacoes.pdf');
    };

    return (
        <div style={{ maxWidth: '960px', margin: '0 auto', padding: '1rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <button
                    onClick={onCloseHistory}
                    style={{
                        background: '#ccc',
                        border: 'none',
                        padding: '0.5rem 1rem',
                        borderRadius: '4px',
                        cursor: 'pointer'
                    }}
                >
                    ← Voltar
                </button>
                <button
                    onClick={handleExportPDF}
                    style={{
                        background: '#28A745',
                        border: 'none',
                        color: 'white',
                        padding: '0.5rem 1rem',
                        borderRadius: '4px',
                        cursor: 'pointer'
                    }}
                >
                    Exportar PDF
                </button>
            </div>

            <h2 style={{ color: '#333', marginBottom: '1rem' }}>
                Histórico de Movimentações
            </h2>

            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1rem' }}>
                <div>
                    <label>De:</label><br/>
                    <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                </div>
                <div>
                    <label>Até:</label><br/>
                    <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                </div>
                <div>
                    <label>Tamanho:</label><br/>
                    <select value={sizeFilter} onChange={e => setSizeFilter(e.target.value)}>
                        <option value="">Todos</option>
                        <option value="L30">30 L</option>
                        <option value="L50">50 L</option>
                        <option value="L100">100 L</option>
                        <option value="L200">200 L</option>
                    </select>
                </div>
                <div style={{ flex: 1, minWidth: '200px' }}>
                    <label>Cliente / Motivo:</label><br/>
                    <input
                        type="text"
                        placeholder="Pesquisar..."
                        value={searchText}
                        onChange={e => setSearchText(e.target.value)}
                        style={{ width: '100%' }}
                    />
                </div>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: 'system-ui, sans-serif' }}>
                <thead>
                <tr>
                    {['Data', 'Tamanho', 'Tipo', 'Qtde', 'Cliente/Motivo'].map(th => (
                        <th key={th} style={{ textAlign: 'left', padding: '0.5rem', borderBottom: '2px solid #eee' }}>
                            {th}
                        </th>
                    ))}
                </tr>
                </thead>
                <tbody>
                {filtered.map(m => (
                    <tr key={m.id}>
                        <td style={{ padding: '0.5rem', borderBottom: '1px solid #f5f5f5' }}>
                            {new Date(m.date).toLocaleString()}
                        </td>
                        <td style={{ padding: '0.5rem', borderBottom: '1px solid #f5f5f5' }}>
                            {`${m.size.substring(1)} L`}
                        </td>
                        <td style={{
                            padding: '0.5rem',
                            borderBottom: '1px solid #f5f5f5',
                            color:
                                m.type === 'ENTRY' ? '#28A745' :
                                    m.type === 'EXIT'  ? '#DC3545' :
                                        '#555'
                        }}>
                            {m.type === 'ENTRY'  ? 'Entrada' : m.type === 'EXIT' ? 'Saída' : 'Ajuste'}
                        </td>
                        <td style={{ padding: '0.5rem', borderBottom: '1px solid #f5f5f5' }}>
                            {m.quantity}
                        </td>
                        <td style={{ padding: '0.5rem', borderBottom: '1px solid #f5f5f5' }}>
                            {m.type === 'EXIT' ? m.client : m.type === 'ADJUSTMENT' ? m.reason : '—'}
                        </td>
                    </tr>
                ))}
                {filtered.length === 0 && (
                    <tr>
                        <td colSpan="5" style={{ padding: '1rem', textAlign: 'center', color: '#777' }}>
                            Nenhuma movimentação encontrada.
                        </td>
                    </tr>
                )}
                </tbody>
            </table>
        </div>
    );
}
