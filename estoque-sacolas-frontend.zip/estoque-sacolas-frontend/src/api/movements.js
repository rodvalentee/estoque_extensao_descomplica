import axios from 'axios';

const API_BASE = 'http://localhost:8080';

export const postEntry = data =>
    axios.post(`${API_BASE}/movements/entry`, data).then(res => res.data);

export const postExit = data =>
    axios.post(`${API_BASE}/movements/exit`, data).then(res => res.data);

export const postAdjustment = data =>
    axios.post(`${API_BASE}/movements/adjustment`, data).then(res => res.data);
export const fetchMovements = () =>
    axios.get(`${API_BASE}/movements`).then(res => res.data);