import axios from 'axios';

const API_BASE = 'http://localhost:8080';

export const fetchStock = () =>
    axios
        .get(`${API_BASE}/stock`)
        .then(res => res.data);
