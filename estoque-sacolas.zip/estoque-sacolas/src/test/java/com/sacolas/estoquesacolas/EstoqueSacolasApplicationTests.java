package com.sacolas.estoquesacolas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstoqueSacolasApplicationTests {

    @Test
    void contextLoads() {
    }

}
