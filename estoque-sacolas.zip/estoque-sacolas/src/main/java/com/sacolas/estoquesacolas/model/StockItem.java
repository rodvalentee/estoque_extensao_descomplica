package com.sacolas.estoquesacolas.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Table("stock_item")
public class StockItem {
    @Id
    private Size size;
    private Integer quantity;
}
