package com.sacolas.estoquesacolas.model;

public enum MovementType {
    ENTRY, EXIT, ADJUSTMENT
}
