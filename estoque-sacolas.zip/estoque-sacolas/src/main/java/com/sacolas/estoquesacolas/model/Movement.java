package com.sacolas.estoquesacolas.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;
import java.time.Instant;

@Data
@Table("movement")
public class Movement {
    @Id
    private Long id;
    private Size size;
    private MovementType type;
    private Instant date;
    private Integer quantity;
    private String client;   // só para EXIT
    private String reason;   // só para ADJUSTMENT
}
