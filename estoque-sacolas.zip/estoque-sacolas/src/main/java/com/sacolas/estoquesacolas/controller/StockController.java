package com.sacolas.estoquesacolas.controller;

import com.sacolas.estoquesacolas.model.StockItem;
import com.sacolas.estoquesacolas.model.Size;
import com.sacolas.estoquesacolas.repository.StockItemRepository;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/stock")
@CrossOrigin(origins = "http://localhost:5173")
public class StockController {

    private final StockItemRepository repo;
    public StockController(StockItemRepository repo) { this.repo = repo; }

    @GetMapping
    public Flux<StockItem> listAll() {
        return repo.findAll();
    }

    @GetMapping("/{size}")
    public Mono<StockItem> getOne(@PathVariable Size size) {
        return repo.findById(size);
    }
}
