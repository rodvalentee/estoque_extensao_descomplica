package com.sacolas.estoquesacolas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstoqueSacolasApplication {

    public static void main(String[] args) {
        SpringApplication.run(EstoqueSacolasApplication.class, args);
    }

}
