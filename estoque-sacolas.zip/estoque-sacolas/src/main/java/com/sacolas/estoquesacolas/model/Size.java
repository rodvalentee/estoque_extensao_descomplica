package com.sacolas.estoquesacolas.model;

public enum Size {
    L30, L50, L100, L200
}
