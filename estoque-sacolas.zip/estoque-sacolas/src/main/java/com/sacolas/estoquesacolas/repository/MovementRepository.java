package com.sacolas.estoquesacolas.repository;

import com.sacolas.estoquesacolas.model.Movement;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface MovementRepository extends ReactiveCrudRepository<Movement, Long> { }
