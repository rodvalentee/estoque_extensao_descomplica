package com.sacolas.estoquesacolas.controller;

import com.sacolas.estoquesacolas.model.Movement;
import com.sacolas.estoquesacolas.model.MovementType;
import com.sacolas.estoquesacolas.repository.MovementRepository;
import com.sacolas.estoquesacolas.repository.StockItemRepository;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.time.Instant;

@RestController
@RequestMapping("/movements")
@CrossOrigin(origins = "http://localhost:5173")
public class MovementController {

    private final MovementRepository movRepo;
    private final StockItemRepository stockRepo;

    public MovementController(MovementRepository movRepo, StockItemRepository stockRepo) {
        this.movRepo = movRepo;
        this.stockRepo = stockRepo;
    }

    @GetMapping
    public Flux<Movement> listAll() {
        return movRepo.findAll();
    }

    @PostMapping("/entry")
    public Mono<Movement> entry(@RequestBody Movement m) {
        m.setType(MovementType.ENTRY);
        m.setDate(Instant.now());
        return movRepo.save(m)
                .flatMap(saved -> stockRepo.findById(saved.getSize())
                        .flatMap(item -> {
                            item.setQuantity(item.getQuantity() + saved.getQuantity());
                            return stockRepo.save(item).thenReturn(saved);
                        })
                );
    }

    // TODO: /exit e /adjustment

    @PostMapping("/exit")
    public Mono<Movement> exit(@RequestBody Movement m) {
        m.setType(MovementType.EXIT);
        m.setDate(Instant.now());
        return movRepo.save(m)
                .flatMap(saved -> stockRepo.findById(saved.getSize())
                        .flatMap(item -> {
                            item.setQuantity(item.getQuantity() - saved.getQuantity());
                            return stockRepo.save(item).thenReturn(saved);
                        })
                );
    }

    @PostMapping("/adjustment")
    public Mono<Movement> adjustment(@RequestBody Movement m) {
        m.setType(MovementType.ADJUSTMENT);
        m.setDate(Instant.now());
        return movRepo.save(m)
                .flatMap(saved -> stockRepo.findById(saved.getSize())
                        .flatMap(item -> {
                            item.setQuantity(item.getQuantity() + saved.getQuantity());
                            return stockRepo.save(item).thenReturn(saved);
                        })
                );
    }

}
