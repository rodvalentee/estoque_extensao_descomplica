package com.sacolas.estoquesacolas.repository;

import com.sacolas.estoquesacolas.model.StockItem;
import com.sacolas.estoquesacolas.model.Size;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface StockItemRepository extends ReactiveCrudRepository<StockItem, Size> { }
